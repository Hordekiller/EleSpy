(function(){const o=document.createElement("link").relList;if(o&&o.supports&&o.supports("modulepreload"))return;for(const e of document.querySelectorAll('link[rel="modulepreload"]'))n(e);new MutationObserver(e=>{for(const r of e)if(r.type==="childList")for(const a of r.addedNodes)a.tagName==="LINK"&&a.rel==="modulepreload"&&n(a)}).observe(document,{childList:!0,subtree:!0});function s(e){const r={};return e.integrity&&(r.integrity=e.integrity),e.referrerPolicy&&(r.referrerPolicy=e.referrerPolicy),e.crossOrigin==="use-credentials"?r.credentials="include":e.crossOrigin==="anonymous"?r.credentials="omit":r.credentials="same-origin",r}function n(e){if(e.ep)return;e.ep=!0;const r=s(e);fetch(e.href,r)}})();function i(t){const o={global_colors:t.globalColors,global_typography:t.globalTypography,css_vars:t.cssVariables};return{version:"3.0",title:`Extracted Kit - ${window.location.hostname}`,type:"kit",data:{kit:{active_breakpoints:["mobile","mobile_extra","tablet","tablet_extra","desktop","widescreen"],conditions:{},settings:o},global_styles:t.generatedCSS,page_settings:{}}}}function l(t){var e,r;const o=new Blob([JSON.stringify(t,null,2)],{type:"application/json"}),s=URL.createObjectURL(o),n=document.createElement("a");n.href=s,n.download=`elespy-kit-${((r=(e=t.data.kit.settings.global_colors.primary)==null?void 0:e.value)==null?void 0:r.replace("#",""))||"export"}.json`,document.body.appendChild(n),n.click(),document.body.removeChild(n),URL.revokeObjectURL(s)}function c(t,o){const s=new Blob([t],{type:"text/css"}),n=URL.createObjectURL(s),e=document.createElement("a");e.href=n,e.download="elespy-extracted.css",document.body.appendChild(e),e.click(),document.body.removeChild(e),URL.revokeObjectURL(n)}async function d(t){try{return await navigator.clipboard.writeText(t),!0}catch{const o=document.createElement("textarea");o.value=t,o.style.position="fixed",o.style.opacity="0",document.body.appendChild(o),o.select();const s=document.execCommand("copy");return document.body.removeChild(o),s}}function u(t){const o=window.location.hostname,s=Object.keys(t.data.kit.settings.global_colors).length,n=Object.keys(t.data.kit.settings.global_typography).length,e=Object.keys(t.data.kit.settings.css_vars).length;return`
=== EleSpy Import Instructions ===

Source: ${o}
Colors: ${s} | Typography: ${n} | CSS Variables: ${e}

Method 1: Elementor Kit Import
1. Save the downloaded .json file
2. Go to WordPress Admin > Elementor > Tools > Import/Export Kit
3. Click "Import Kit"
4. Select the downloaded .json file
5. Choose what to import (Colors, Typography, Global Settings)
6. Click "Import"

Method 2: Manual CSS Import
1. Copy the CSS variables
2. Go to WordPress Admin > Elementor > Settings > Custom CSS
3. Paste the CSS variables in the "Custom CSS" field
4. Save changes

Method 3: Theme Customizer
1. Copy the CSS variables
2. Go to Appearance > Customize > Additional CSS
3. Paste the CSS variables
4. Publish

Note: Some settings may require Elementor Pro for full compatibility.
`.trim()}export{u as a,c as b,d as c,l as d,i as g};
